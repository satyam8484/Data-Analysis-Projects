Here we are Solving Solving real world data science tasks with Python Pandas!

we are performing data analysis on sales data 
we hava data for each month 1st we will combine it into one CSV using pandas (All_month_Data.csv) then perform Data Analysis on it


you can do Same task using Excel but it'll take time for processing as it is very large Data. still i have given answer of some questions using Excel 
Check out that also ( Good exercise to learn Excel )

